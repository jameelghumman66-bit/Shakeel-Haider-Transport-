const menuToggle = document.querySelector(".menu-toggle");
const nav = document.querySelector("#main-nav");
if (menuToggle) {
  menuToggle.addEventListener("click", () => nav.classList.toggle("open"));
}
document.querySelectorAll("#main-nav a").forEach(a => {
  a.addEventListener("click", () => nav.classList.remove("open"));
});

const form = document.querySelector("#quote-form");
const status = document.querySelector("#form-status");
form.addEventListener("submit", (e) => {
  e.preventDefault();
  const name = document.querySelector("#name").value.trim();
  const phone = document.querySelector("#phone").value.trim();
  const equipment = document.querySelector("#equipment-select").value;
  const duration = document.querySelector("#duration").value;
  const location = document.querySelector("#location").value.trim();
  const message = document.querySelector("#message").value.trim();

  const text = [
    "Hello Shakeel Haider Transport LLC,",
    `I need a quote for: ${equipment}`,
    `Rental duration: ${duration}`,
    `Name: ${name}`,
    `Phone: ${phone}`,
    location ? `Site location: ${location}` : "",
    message ? `Details: ${message}` : ""
  ].filter(Boolean).join("\n");

  window.open(`https://wa.me/971556540158?text=${encodeURIComponent(text)}`, "_blank");
  status.textContent = "Opening WhatsApp with your quotation request...";
});
