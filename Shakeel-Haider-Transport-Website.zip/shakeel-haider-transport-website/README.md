# Shakeel Haider Transport LLC Website

A responsive static website for Shakeel Haider Transport LLC, Dubai, UAE.

## Files
- `index.html` — complete website structure/content
- `style.css` — responsive design and styling
- `script.js` — mobile menu and WhatsApp quotation form
- `assets/website-mockup.png` — website visual asset

## Run locally
Open `index.html` in any modern browser.

## Publish on GitHub Pages
1. Create a GitHub repository.
2. Upload all files and the `assets` folder.
3. Go to Settings → Pages.
4. Select the `main` branch and `/root` folder.
5. Save. GitHub will provide your public website link.

## Important
Replace `assets/website-mockup.png` with your actual equipment photos for the final production version. Replace the placeholder TikTok/Facebook `#` links with the company's actual social URLs.
